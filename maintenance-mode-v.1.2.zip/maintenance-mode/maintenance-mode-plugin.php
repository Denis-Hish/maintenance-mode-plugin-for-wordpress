<?php
/*
Plugin Name: Maintenance Mode Plugin
Description: Displays a custom maintenance page when activated manually or via timers. Ability to use your own HTML code. Access to the site based on user roles.
Version: 1.2
Author: Denis Nazarow
Requires at least: 4.6
Requires PHP: 5.6
Text Domain: maintenance-mode-plugin
Domain Path: /languages
*/

if (!defined('ABSPATH')) {
    exit; 
}

class Maintenance_Mode_Plugin {
    private $is_updating = false;

    public function __construct() {
        add_action('admin_menu', array($this, 'create_admin_menu'));
        add_action('admin_init', array($this, 'register_settings'));
        add_action('template_redirect', array($this, 'check_maintenance_mode'));
        add_action('admin_notices', array($this, 'display_admin_notice'));

        add_action('upgrader_pre_install', array($this, 'start_maintenance_mode_on_update'), 10, 2);
        add_action('upgrader_process_complete', array($this, 'stop_maintenance_mode_on_update'), 10, 2);
        add_action('pre_auto_update', array($this, 'start_maintenance_mode_on_core_update'), 10, 2);
        add_action('auto_update_complete', array($this, 'stop_maintenance_mode_on_core_update'), 10, 2);

        add_filter('enable_maintenance_mode', array($this, 'disable_default_maintenance_mode'), 10, 2);

        register_activation_hook(__FILE__, array($this, 'activate_plugin'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate_plugin'));
    }

    public function create_admin_menu() {
        add_options_page('Maintenance Mode', 'Maintenance Mode', 'manage_options', 'maintenance-mode', array($this, 'settings_page'));
    }

    public function register_settings() {
        register_setting('maintenance_mode_settings_group', 'maintenance_mode_enabled');
        register_setting('maintenance_mode_settings_group', 'maintenance_mode_custom_html');
        register_setting('maintenance_mode_settings_group', 'maintenance_mode_start_time');
        register_setting('maintenance_mode_settings_group', 'maintenance_mode_end_time');
        register_setting('maintenance_mode_settings_group', 'maintenance_mode_allowed_roles');
        register_setting('maintenance_mode_settings_group', 'maintenance_mode_completed_notice', array('default' => ''));

        add_settings_section('maintenance_mode_settings_section', 'Настройки режима обслуживания', null, 'maintenance-mode');

        add_settings_field('maintenance_mode_enabled', 'Включить режим обслуживания', array($this, 'render_maintenance_mode_enabled_field'), 'maintenance-mode', 'maintenance_mode_settings_section');
        add_settings_field('maintenance_mode_custom_html', 'Кастомный HTML', array($this, 'render_custom_html_field'), 'maintenance-mode', 'maintenance_mode_settings_section');
        add_settings_field('maintenance_mode_start_time', 'Время начала (опционально)', array($this, 'render_start_time_field'), 'maintenance-mode', 'maintenance_mode_settings_section');
        add_settings_field('maintenance_mode_end_time', 'Время окончания (опционально)', array($this, 'render_end_time_field'), 'maintenance-mode', 'maintenance_mode_settings_section');
        add_settings_field('maintenance_mode_allowed_roles', 'Разрешенные роли', array($this, 'render_allowed_roles_field'), 'maintenance-mode', 'maintenance_mode_settings_section');
    }

    public function settings_page() {
        ?>
        <div class="wrap">
            <h1>Настройки режима обслуживания</h1>
            <form method="post" action="options.php">
                <?php
                settings_fields('maintenance_mode_settings_group');
                do_settings_sections('maintenance-mode');
                submit_button();
                ?>
            </form>
        </div>
        <?php
    }

    public function render_maintenance_mode_enabled_field() {
        $value = get_option('maintenance_mode_enabled');
        echo '<input type="checkbox" name="maintenance_mode_enabled" value="1"' . checked(1, $value, false) . '>';
    }

    public function render_custom_html_field() {
        $value = get_option('maintenance_mode_custom_html');
        echo '<textarea name="maintenance_mode_custom_html" rows="10" cols="50" class="large-text">' . esc_textarea($value) . '</textarea>';
    }

    public function render_start_time_field() {
        $value = get_option('maintenance_mode_start_time', '');
        echo '<input type="datetime-local" name="maintenance_mode_start_time" value="' . esc_attr($value) . '">';
        echo '<p class="description">Установите время начала планового обслуживания (опционально).</p>';
    }

    public function render_end_time_field() {
        $value = get_option('maintenance_mode_end_time', '');
        echo '<input type="datetime-local" name="maintenance_mode_end_time" value="' . esc_attr($value) . '">';
        echo '<p class="description">Установите время окончания планового обслуживания (опционально).</p>';
    }

    public function render_allowed_roles_field() {
        $allowed_roles = get_option('maintenance_mode_allowed_roles', array());
        if (!is_array($allowed_roles)) $allowed_roles = (array) $allowed_roles;
        $roles = get_editable_roles();
        foreach ($roles as $role_key => $role_data) {
            $checked = in_array($role_key, $allowed_roles) ? 'checked' : '';
            echo '<label><input type="checkbox" name="maintenance_mode_allowed_roles[]" value="' . esc_attr($role_key) . '" ' . $checked . '> ' . esc_html($role_data['name']) . '</label><br>';
        }
        echo '<p class="description">Выберите роли, которые могут заходить на сайт во время обслуживания.</p>';
    }

    private function get_maintenance_status() {
        $is_enabled = get_option('maintenance_mode_enabled');
        $start_time = get_option('maintenance_mode_start_time');
        $end_time = get_option('maintenance_mode_end_time');
        $current_time = current_time('timestamp');
    
        $wp_timezone = get_option('timezone_string');
        if ($wp_timezone) {
            $timezone = new DateTimeZone($wp_timezone);
        } else {
            $gmt_offset = get_option('gmt_offset');
            $offset_hours = floor($gmt_offset);
            $offset_minutes = ($gmt_offset - $offset_hours) * 60;
            $timezone_string = sprintf('%+03d:%02d', $offset_hours, abs($offset_minutes));
            $timezone = new DateTimeZone($timezone_string);
        }
    
        $is_scheduled = false;
        $start_timestamp = null;
        $end_timestamp = null;
    
        // Вычисляем start_timestamp, если задано время начала
        if ($start_time) {
            try {
                $start_date = DateTime::createFromFormat('Y-m-d\TH:i', $start_time, new DateTimeZone('UTC'));
                if ($start_date) {
                    $start_date->setTimezone($timezone);
                    $start_timestamp = $start_date->getTimestamp();
                    error_log("Start time: $start_time, Timestamp: $start_timestamp (" . date('Y-m-d H:i', $start_timestamp) . ")");
                }
            } catch (Exception $e) {
                error_log("Error parsing start time: " . $e->getMessage());
            }
        }
    
        // Вычисляем end_timestamp, если задано время окончания
        if ($end_time) {
            try {
                $end_date = DateTime::createFromFormat('Y-m-d\TH:i', $end_time, new DateTimeZone('UTC'));
                if ($end_date) {
                    $end_date->setTimezone($timezone);
                    $end_timestamp = $end_date->getTimestamp();
                    error_log("End time: $end_time, Timestamp: $end_timestamp (" . date('Y-m-d H:i', $end_timestamp) . ")");
                }
            } catch (Exception $e) {
                error_log("Error parsing end time: " . $e->getMessage());
            }
        }
    
        error_log("Current time: $current_time (" . date('Y-m-d H:i', $current_time) . ")");
    
        // Логика для автоматического включения и выключения
        if ($start_timestamp && !$end_timestamp) {
            // Только время начала: включаем, если время наступило
            $is_scheduled = ($current_time >= $start_timestamp);
            if ($is_scheduled && !$is_enabled) {
                update_option('maintenance_mode_enabled', true);
                $is_enabled = true;
            }
        } elseif ($end_timestamp && !$start_timestamp) {
            // Только время окончания: выключаем, если время прошло
            if ($current_time > $end_timestamp && $is_enabled && !$this->is_updating) {
                update_option('maintenance_mode_enabled', false);
                $is_enabled = false;
            }
        } elseif ($start_timestamp && $end_timestamp) {
            // Оба времени: включаем и выключаем в диапазоне
            $is_scheduled = ($current_time >= $start_timestamp && $current_time <= $end_timestamp);
            if ($is_scheduled && !$is_enabled) {
                update_option('maintenance_mode_enabled', true);
                $is_enabled = true;
            } elseif ($current_time > $end_timestamp && $is_enabled && !$this->is_updating) {
                update_option('maintenance_mode_enabled', false);
                $is_enabled = false;
            }
        }
    
        $is_maintenance_active = $is_enabled || $this->is_updating || $is_scheduled;
        $reason = '';
        if ($this->is_updating) {
            $reason = 'Сайт в данный момент обновляется.';
        } elseif ($is_scheduled) {
            $reason = 'Сайт находится в режиме планового обслуживания.';
        } elseif ($is_enabled) {
            $reason = 'Сайт находится в ручном режиме обслуживания.';
        }
    
        return array(
            'active' => $is_maintenance_active,
            'reason' => $reason,
            'scheduled' => $is_scheduled,
            'start_timestamp' => $start_timestamp,
            'end_timestamp' => $end_timestamp
        );
    }

    public function check_maintenance_mode() {
        $status = $this->get_maintenance_status();
        $allowed_roles = get_option('maintenance_mode_allowed_roles', array());
        if (!is_array($allowed_roles)) $allowed_roles = (array) $allowed_roles;
        $user = wp_get_current_user();
        $user_roles = (array) $user->roles;
        $has_allowed_role = !empty(array_intersect($allowed_roles, $user_roles));
    
        $start_time = get_option('maintenance_mode_start_time');
        $end_time = get_option('maintenance_mode_end_time');
        $current_time = current_time('timestamp');
    
        if ($end_time) {
            $wp_timezone = get_option('timezone_string');
            if (!$wp_timezone) {
                $gmt_offset = get_option('gmt_offset');
                $offset_hours = floor($gmt_offset);
                $offset_minutes = ($gmt_offset - $offset_hours) * 60;
                $timezone_string = sprintf('%+03d:%02d', $offset_hours, abs($offset_minutes));
                $timezone = new DateTimeZone($timezone_string);
            } else {
                $timezone = new DateTimeZone($wp_timezone);
            }
            try {
                $end_date = DateTime::createFromFormat('Y-m-d\TH:i', $end_time, new DateTimeZone('UTC'));
                if ($end_date) {
                    $end_date->setTimezone($timezone);
                    $end_timestamp = $end_date->getTimestamp();
                    if ($current_time > $end_timestamp && !$this->is_updating) {
                        // Очищаем таймеры и записываем уведомление о завершении
                        update_option('maintenance_mode_start_time', '');
                        update_option('maintenance_mode_end_time', '');
                        $completed_time = date_i18n('Y-m-d H:i', $end_timestamp);
                        update_option('maintenance_mode_completed_notice', sprintf(
                            'Плановое обслуживание завершено в %s.',
                            $completed_time
                        ));
                        error_log("Maintenance ended. Current: $current_time, End: $end_timestamp, Completed: $completed_time");
                    }
                }
            } catch (Exception $e) {
                error_log("Error in check_maintenance_mode: " . $e->getMessage());
            }
        }
    
        if ($status['active'] && !$has_allowed_role) {
            $this->display_maintenance_page();
            exit;
        }
    }

    public function display_admin_notice() {
        $status = $this->get_maintenance_status();
        $completed_notice = get_option('maintenance_mode_completed_notice', '');
        $start_time = get_option('maintenance_mode_start_time');
        $end_time = get_option('maintenance_mode_end_time');
        $current_time = current_time('timestamp');
    
        $wp_timezone = get_option('timezone_string');
        if ($wp_timezone) {
            $timezone = new DateTimeZone($wp_timezone);
        } else {
            $gmt_offset = get_option('gmt_offset');
            $offset_hours = floor($gmt_offset);
            $offset_minutes = ($gmt_offset - $offset_hours) * 60;
            $timezone_string = sprintf('%+03d:%02d', $offset_hours, abs($offset_minutes));
            $timezone = new DateTimeZone($timezone_string);
        }
    
        $start_timestamp = null;
        $end_timestamp = null;
        if ($start_time) {
            $start_date = DateTime::createFromFormat('Y-m-d\TH:i', $start_time, new DateTimeZone('UTC'));
            if ($start_date) {
                $start_date->setTimezone($timezone);
                $start_timestamp = $start_date->getTimestamp();
            }
        }
        if ($end_time) {
            $end_date = DateTime::createFromFormat('Y-m-d\TH:i', $end_time, new DateTimeZone('UTC'));
            if ($end_date) {
                $end_date->setTimezone($timezone);
                $end_timestamp = $end_date->getTimestamp();
            }
        }
    
        // Уведомление о предстоящем обслуживании
        if ($start_timestamp && $current_time < $start_timestamp) {
            $message = 'Сайт будет находиться в режиме планового обслуживания. Запланировано включение с ' . date_i18n('Y-m-d H:i', $start_timestamp);
            if ($end_timestamp) {
                $message .= ' до ' . date_i18n('Y-m-d H:i', $end_timestamp);
            }
            $message .= '.';
            echo '<div class="notice notice-info is-dismissible"><p><strong>Режим обслуживания:</strong> ' . esc_html($message) . ' <a href="' . admin_url('options-general.php?page=maintenance-mode') . '">Просмотр настроек</a></p></div>';
        }
    
        // Уведомление о текущем обслуживании
        if ($status['active']) {
            $reason = $status['reason'];
            if ($status['scheduled'] && $end_timestamp) {
                $reason = 'Сайт находится в режиме планового обслуживания. Запланировано выключение в ' . date_i18n('Y-m-d H:i', $end_timestamp) . '.';
            }
            echo '<div class="notice notice-error is-dismissible"><p><strong>Режим обслуживания активен:</strong> ' . esc_html($reason) . ' <a href="' . admin_url('options-general.php?page=maintenance-mode') . '">Управление настройками</a></p></div>';
        }
    
        // Уведомление о завершении
        if (!empty($completed_notice)) {
            echo '<div class="notice notice-success is-dismissible"><p><strong>Режим обслуживания:</strong> ' . esc_html($completed_notice) . ' <a href="' . admin_url('options-general.php?page=maintenance-mode') . '">Просмотр настроек</a></p></div>';
            update_option('maintenance_mode_completed_notice', '');
        }
    }

    public function start_maintenance_mode_on_update($upgrader, $extra) {
        if (isset($extra['type']) && in_array($extra['type'], ['plugin', 'theme'])) $this->is_updating = true;
    }

    public function stop_maintenance_mode_on_update($upgrader, $extra) {
        if (isset($extra['type']) && in_array($extra['type'], ['plugin', 'theme'])) $this->is_updating = false;
    }

    public function start_maintenance_mode_on_core_update($type, $item) {
        if ($type === 'core') $this->is_updating = true;
    }

    public function stop_maintenance_mode_on_core_update($type, $item) {
        if ($type === 'core') $this->is_updating = false;
    }

    public function disable_default_maintenance_mode($enable, $context) {
        if ($context === 'install' || $context === 'update') return false;
        return $enable;
    }

    public function display_maintenance_page() {
        $custom_html = get_option('maintenance_mode_custom_html', '');
        if (!empty($custom_html)) {
            echo $custom_html;
        } else {
            include(plugin_dir_path(__FILE__) . 'maintenance-mode-template.html');
        }
        header('HTTP/1.1 503 Service Temporarily Unavailable');
        header('Retry-After: 3600');
        exit;
    }

    public function activate_plugin() {
        add_option('maintenance_mode_enabled', false);
        add_option('maintenance_mode_custom_html', '');
        add_option('maintenance_mode_start_time', '');
        add_option('maintenance_mode_end_time', '');
        add_option('maintenance_mode_allowed_roles', array('administrator'));
        add_option('maintenance_mode_completed_notice', '');
    }

    public function deactivate_plugin() {
        delete_option('maintenance_mode_enabled');
        delete_option('maintenance_mode_custom_html');
        delete_option('maintenance_mode_start_time');
        delete_option('maintenance_mode_end_time');
        delete_option('maintenance_mode_allowed_roles');
        delete_option('maintenance_mode_completed_notice');
    }
}

new Maintenance_Mode_Plugin();